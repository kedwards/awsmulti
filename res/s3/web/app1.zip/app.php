<!DOCTYPE html>
<html>
<head>
	<title>Hello Onica</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        *
        {
        padding: 0px;
        margin: 0px;
        font-family: monospace;
        }
        header
        {
            height: 100vh;
            background-image: url('https://images.unsplash.com/photo-1500248292521-c4b0ca3d4cd7?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=890&q=80');
            display: flex;
            flex-direction: column;
            align-items: center;
            background-size: cover;
            justify-content: center;
        }
        em 
        {
            color: red;
        }
    </style>
</head>
<body>
	<header>
		<h1>Welcome to the Onica Test Infra Site</h1>
		<h3>Running on host <em><?php echo gethostname(); ?></em></h3>
	</header>
</body>
</html>